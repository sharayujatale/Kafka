package com.enduser.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.KafkaListener;

import com.enduser.entity.Product;

@Configuration
public class KafkaConfig {
	
//	@KafkaListener(topics=AppConstant.LOCATION_UPDATE_TOPIC, groupId= AppConstant.GROUP_ID)
//	public void updatedLocation(String value) {
//		System.out.println(value);
//		
//	}
	
	@KafkaListener(topics=AppConstant.LOCATION_UPDATE_TOPIC, groupId= AppConstant.GROUP_ID)
	public void updatedProduct(Product product) {
		System.out.println(product);
		
	}

}
