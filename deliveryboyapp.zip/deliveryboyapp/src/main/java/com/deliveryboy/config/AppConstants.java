package com.deliveryboy.config;

public class AppConstants {
	
	public static final String LOCATION_TOPIC_NAME="Location-update-topic";

}
